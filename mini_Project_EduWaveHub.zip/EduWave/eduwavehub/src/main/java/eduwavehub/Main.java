package eduwavehub;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;



@WebServlet("/Main")
public class Main extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public Main() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	
		 
	     
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		
		  response.setContentType("text/html;charset=UTF-8");
	        PrintWriter out = response.getWriter();
	     
	        String name = request.getParameter("name");
	        String username = request.getParameter("username");
	        String email = request.getParameter("email");
	        String phone = request.getParameter("phone");
	        String pass = request.getParameter("pass");
	        
	        RegisBean rb = new RegisBean();
	        rb.setName(name);
	        rb.setUsername(username);
	        rb.setEmail(email);
	        rb.setPhone(phone);
	        rb.setPass(pass);
	        
	        Userdb us = new Userdb();
	        
	        String s1 = us.insertuser(rb);
	        out.println(s1);
	        
	        
	      /*  out.println(name);
	        out.println(username);
	        out.println(email);
	        out.println(phone);
	        out.println(pass);
	        
	        
	        
	        
	      /*  try 
	        {
	         
	            // loading drivers for mysql
	            Class.forName("com.mysql.jdbc.Driver");
	             
	            //creating connection with the database 
	            Connection con = DriverManager.getConnection
	                        ("jdbc:mysql://localhost:3306/registration","root","9876");
	 
	            PreparedStatement ps = con.prepareStatement         
	            ("insert into regi values(?,?,?,?,?)");
	 
	            ps.setString(1, name);
	            ps.setString(2, username);
	            ps.setString(3, email);
	            ps.setString(4, phone);
	            ps.setString(5, pass);
	            int i= ps.executeUpdate();
      
	            if(i > 0)
	            {
	                out.println("<html><body>");
	                out.println("<h1>You are successfully registered at eduwavehub</h1>");
	                out.println("</html></body>");
	            }
	            else {
	            	   out.println("<html><body>");
		                out.println("<h1>You are  not successfully registered at eduwavehub</h1>");
		                out.println("</html></body>");
	            	
	            }
	         
	        }
	        catch(Exception se) 
	        {
	            se.printStackTrace();
	            out.println("error");
	        }*/
	}

}
