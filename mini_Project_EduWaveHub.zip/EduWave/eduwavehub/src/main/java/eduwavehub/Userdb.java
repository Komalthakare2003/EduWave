package eduwavehub;

import java.sql.Connection;
import java.sql.*;
public class Userdb 
{
	String s1=null;
	public  String insertuser(RegisBean rb)
	{ 
		MyDb db =  new MyDb();
		Connection con = db.getcon();
		try 
		{
			Statement st = con.createStatement();		
			//RegisBean rb;
			
			st.executeUpdate("insert into regi(name,username,email,phone,password) "
					+ "values('"+rb.getName()+"','"+rb.getUsername()+"','"+rb.getEmail()+"','"+rb.getPhone()+"','"+rb.getPass()+"')");
			
			s1="data inserted";
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			
		}
		   return s1;
		
	}

}
