package eduwavehub;
import java.sql.*;

public class MyDb {
	Connection con = null;
	public Connection getcon() 
	{
		try 
		{
		Class.forName("com.mysql.jdbc.Driver");
		DriverManager.getConnection("jdbc:mysql://localhost:3306/registration", "root","9876");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		return null;
	}
	
	
}
