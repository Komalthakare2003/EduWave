package eduwavehub;

import jakarta.servlet.ServletException;


import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/conn")
public class conn extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}
       
    
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		
		String username=req.getParameter("username");
		System.out.println(username);
		String password=req.getParameter("password");
		System.out.println(password);
		
		PrintWriter ps = resp.getWriter();
		ps.print("username=" + username);
		ps.print("password=" + password);
		
	}

}
